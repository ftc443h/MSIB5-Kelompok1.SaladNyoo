# MSIB5-Kelompok1.SaladNyoo

Kelas Industri Web Fullstack Developer (Bootstrap &amp; SASS)
Nama Kelompok 1 (Salad Nyoo):

1. Fatchan Muhammad Hakim => Leader (Ketua)
2. Bagas Adi Kurniawan => Anggota
3. Satriya Yoga Madhasatya => Anggota
4. Rani Kurniawati => Anggota
5. Dela Septriani => Anggota